<template>
  <div class="dashboard-container">
    <div class="dashboard-text">欢迎使用代码生成工具</div>
  </div>
</template>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 18px;
    line-height: 46px;
  }
}
</style>
